# covidanalysis
Name: Mateusz Kolodziejczyk
Student Number: 20084190